# MarioPlatform
A Mario Platform Game in Java Graphics2D
