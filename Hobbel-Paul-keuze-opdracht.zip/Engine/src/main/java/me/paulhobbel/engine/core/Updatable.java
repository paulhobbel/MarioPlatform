package me.paulhobbel.engine.core;

public interface Updatable {
    void update(double dt);
}
