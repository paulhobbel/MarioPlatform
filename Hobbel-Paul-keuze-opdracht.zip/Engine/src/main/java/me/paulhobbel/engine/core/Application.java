package me.paulhobbel.engine.core;

public abstract class Application {

    public void init() {

    }

    public void update(double elapsedTime) {

    }
}
