package me.paulhobbel.engine.core;

public interface Disposable {
    void dispose();
}
