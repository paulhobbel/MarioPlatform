package me.paulhobbel.engine.core;

public class EngineSettings {
    public int width = 320;
    public int height = 240;
    public float scale = 1f;
    public int fps = 60;
    public String title = "PEngine V0.1";
}
