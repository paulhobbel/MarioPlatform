package me.paulhobbel.engine.physics.box2d;

public class BodyDef extends org.jbox2d.dynamics.BodyDef {
}
