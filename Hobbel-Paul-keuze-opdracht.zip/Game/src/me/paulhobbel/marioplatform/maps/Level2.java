package me.paulhobbel.marioplatform.maps;

public class Level2 extends Level {
    public Level2() {
        super("/maps/level2.json");
    }

    @Override
    public void onLevelEnd() {

    }
}
